var texto:string="Hola Mundo"
console.log(texto)
