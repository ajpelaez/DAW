import {Component} from 'angular2/core';
 
@Component({
    selector: 'my-app',
    template: '<h1>Hola Mundo (by TwoBy2)</h1>'
})
export class AppComponent { }
