export class Libro {
    constructor(public titulo:string, public tematica:string) {
    }
}
