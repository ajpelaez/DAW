export class Libro {
  id: number;
  titulo: string;
  autor: string;
}
