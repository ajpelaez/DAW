import { Libro } from './libro.model';

export const LIBROS: Libro[] = [{
  "id": 1,
  "titulo": "El Quijote",
  "autor": "Cervantes"
},{
  "id": 2,
  "titulo": "Hamlet",
  "autor": "Shakespeare"
}];
