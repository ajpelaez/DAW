
exports.list_all_tareas = function(req, res) {res.send('<Lista de tareas>');};
exports.create_tarea = function(req, res) {res.send('Tarea creada');};
exports.read_tarea = function(req, res) {res.send('<Tarea>');};
exports.update_tarea = function(req, res) {res.send('Tarea modificada');};
exports.delete_tarea = function(req, res) {res.send('Tarea eliminada');};
